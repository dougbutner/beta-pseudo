
// --- Compile a Smart Contract --- \\
eosio-cpp -abigen -o hello.wasm hello.cpp

eosio-cpp -abigen -o daclifycore.wasm daclifycore.cpp



// --- Things to Investigate --- \\

EOSIO_REFLECT // atomicassets.cpp - eden

buf() // elections.cpp - eden

std::reverse // - Study the cpp-17 std functions 


// --- hpp --- \\


// Multi-index tables
TABLE proposals {
  uint64_t id;
  string title;
  string description;
  name proposer;
  vector<action> actions;
  time_point_sec submitted;
  time_point_sec expiration;
  vector<name> approvals;
  name required_threshold;
  name last_actor;
  checksum256 trx_id;

  auto primary_key() const { return id; }
  uint64_t by_threshold() const { return required_threshold.value; }
  uint64_t by_proposer() const { return proposer.value; }
  uint64_t by_expiration() const { return expiration.sec_since_epoch(); }
};
typedef multi_index<name("proposals"), proposals,
  eosio::indexed_by<"bythreshold"_n, eosio::const_mem_fun<proposals, uint64_t, &proposals::by_threshold>>,
  eosio::indexed_by<"byproposer"_n, eosio::const_mem_fun<proposals, uint64_t, &proposals::by_proposer>>,
  eosio::indexed_by<"byexpiration"_n, eosio::const_mem_fun<proposals, uint64_t, &proposals::by_expiration>>
> proposals_table;

// Inline Actions
[[eosio::on_notify("bluxbluxblux::transfer")]]
void on_transfer(name from, name to, asset quantity, string memo);


// --- cpp --- \\

//For inline actions
void eosio::action::send_context_free() const


// --- Check Statement --- \\
check( true, "If false an error message will appear" );
check( existing != statstable.end(), "token with symbol does not exist" );


typedef eosio::multi_index<
      "tweeties"_n,
      tweet,
      indexed_by<"time"_n, const_mem_fun<tweet, uint64_t, &tweet::by_time>>>
      tweets;
      
      
      
// --- Basic Setter Action  (int) --- \\
ACTION BancorNetwork::setmaxfee(uint64_t max_affiliate_fee) {
    require_auth(get_self());

    settings settings_table(get_self(), get_self().value);
    auto st = settings_table.find("settings"_n.value);
    check(max_affiliate_fee > 0 && max_affiliate_fee <= MAX_FEE, "fee outside resolution");

    if (st == settings_table.end())
        settings_table.emplace(get_self(), [&](auto& s) {
            s.max_fee = max_affiliate_fee;
        });
    else
        settings_table.modify(st, same_payer, [&](auto& s) {
            s.max_fee = max_affiliate_fee;
        });
}

// --- Updater action (no insert, update only) --- \\

void inductions::update_video(const induction& induction, const std::string& video)
{
   check_valid_induction(induction);
   validate_video(video);

   induction_tb.modify(induction_tb.iterator_to(induction), eosio::same_payer,
                       [&](auto& row) { row.video() = video; });

   reset_endorsements(induction.id());
}


// --- Checks if record exists in table (2 part)--- \\

bool inductions::is_invitee(uint64_t id, eosio::name invitee) const
{
   auto& induction = get_induction(id);
   return induction.invitee() == invitee;
}

// Returns custom RECORD (induction&) according to TABLE 
const induction& inductions::get_induction(uint64_t id) const
{
   return induction_tb.get(id, "unable to find induction");
}


// --- Clear all values from table --- \\

void bylaws::clear_all() { clear_table(bylaws_tb); }


// --- Loop through tabls until all values are found --- \\ 
void bylaws::on_resign(eosio::name member)
{
   for (auto key : {proposed, pending})
   {
      auto pos = bylaws_tb.find(key.value);
      if (pos != bylaws_tb.end())
      {
         auto approval_iter =
             std::find(pos->approvals().begin(), pos->approvals().end(), member);
         if (approval_iter != pos->approvals().end())
         {
            bylaws_tb.modify(pos, contract,
                             [&](auto& row) { row.approvals().erase(approval_iter); });
         }
      }
   }
}
