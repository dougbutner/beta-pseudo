#include "cardgame.hpp"

void cardgame::login(name username){
  // Check action is authorized
  require_auth(username);
  
  // Add user if not already there
  auto user_iterator = _users.find(username.value);
  
  if (user_iterator == _users.end()){
    user_iterator = _users.emplace( username, [&](auto& new_user){
      new_user.username = username;
  });
  }
}//END login()


void cardgame::startgame(name username){
  require_auth(username);
  auto& user = _users.get(username.value, "User doesn't exist");
  
  _users.modify(user, username, [&](auto& modified_user) {
    // Create a new game
    game game_data;

    // Draw 4 cards each for the player and the AI
    for (uint8_t i = 0; i < 4; i++) {
      draw_one_card(game_data.deck_player, game_data.hand_player);
      draw_one_card(game_data.deck_ai, game_data.hand_ai);
    }

    // Assign the newly created game to the player
    modified_user.game_data = game_data;
  });
}

// Calculate the score for the current ai card given the  strategy and the player hand cards
int cardgame::calculate_ai_card_score(const int strategy_idx, 
                                      const int8_t life_ai,
                                      const card& ai_card, 
                                      const vector<uint8_t> hand_player) {
   int card_score = 0;
   for (int i = 0; i < hand_player.size(); i++) {
      const auto player_card_id = hand_player[i];
      const auto player_card = card_dict.at(player_card_id);

      int ai_attack_point = calculate_attack_point(ai_card, player_card);
      int player_attack_point = calculate_attack_point(player_card, ai_card);

      // Accumulate the card score based on the given strategy
      switch (strategy_idx) {
        case 0: {
          card_score += ai_best_card_win_strategy(ai_attack_point, player_attack_point);
          break;
        }
        case 1: {
          card_score += ai_min_loss_strategy(ai_attack_point, player_attack_point);
          break;
        }
        case 2: {
          card_score += ai_points_tally_strategy(ai_attack_point, player_attack_point);
          break;
        }
        default: {
          card_score += ai_loss_prevention_strategy(life_ai, ai_attack_point, player_attack_point);
          break;
        }
      }
    }
    return card_score;
}


void cardgame::endgame(name username) {
  // Ensure this action is authorized by the player
  require_auth(username);
  // Get the user and reset the game
  auto& user = _users.get(username.value, "User doesn't exist");
  _users.modify(user, username, [&](auto& modified_user) {
  modified_user.game_data = game();
});
}

void cardgame::playcard(name username, uint8_t player_card_idx) {
  // Ensure this action is authorized by the player
  require_auth(username);

  // Checks that selected card is valid
  check(player_card_idx < 4, "playcard: Invalid hand index");
  
  auto& user = _users.get(username.value, "User doesn't exist");

  // Verify game status is suitable for the player to play a card
  check(user.game_data.status == ONGOING,
               "playcard: This game has ended. Please start a new one");
  check(user.game_data.selected_card_player == 0,
               "playcard: The player has played his card this turn!");
               
    _users.modify(user, username, [&](auto& modified_user) {
      game& game_data = modified_user.game_data;

      // Assign the selected card from the player's hand
      game_data.selected_card_player = game_data.hand_player[player_card_idx];
      game_data.hand_player[player_card_idx] = 0;
      
      // AI picks a card
      int ai_card_idx = ai_choose_card(game_data);
      game_data.selected_card_ai = game_data.hand_ai[ai_card_idx];
      game_data.hand_ai[ai_card_idx] = 0;
      
      resolve_selected_cards(game_data);
      
          update_game_status(modified_user);
    });

}


void cardgame::nextround(name username) {
  // Ensure this action is authorized by the player
  require_auth(username);

  auto& user = _users.get(username.value, "User doesn't exist");

  // Verify game status
  check(user.game_data.status == ONGOING, 
              "nextround: This game has ended. Please start a new one.");
  check(user.game_data.selected_card_player != 0 && user.game_data.selected_card_ai != 0,
               "nextround: Please play a card first.");
               
   _users.modify(user, username, [&](auto& modified_user) {
     game& game_data = modified_user.game_data;

     // Reset selected card and damage dealt
     game_data.selected_card_player = 0;
     game_data.selected_card_ai = 0;
     game_data.life_lost_player = 0;
     game_data.life_lost_ai = 0;
     
     // Draw card for the player and the AI
if (game_data.deck_player.size() > 0) draw_one_card(game_data.deck_player, game_data.hand_player);
if (game_data.deck_ai.size() > 0) draw_one_card(game_data.deck_ai, game_data.hand_ai);

   });
}
